<?php
?>
<html>
    <head>
        <title>CodeIgnitor Tutorial</title>
    </head>
    <body>
        <h1><?php echo $title ?> </h1> 